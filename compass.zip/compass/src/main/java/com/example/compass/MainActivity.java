package com.example.compass;

import android.Manifest;
import android.content.Intent;
import android.content.res.Configuration;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.widget.ImageView;
import android.widget.Toast;

import com.example.compass.auth.FingerprintActivity;
import com.example.compass.utils.LocaleHelper;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements SensorEventListener {

    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private ImageView compassImage;
    private float currentDegree = 0f;

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // منع لقطات الشاشة
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

        compassImage = findViewById(R.id.compassImage);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);

        // القائمة الجانبية
        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);

        // فتح القائمة عند الضغط على الأيقونة
        findViewById(R.id.menuIcon).setOnClickListener(v ->
                drawerLayout.openDrawer(Gravity.RIGHT));

        // التعامل مع عناصر القائمة
        navigationView.setNavigationItemSelectedListener(this::handleMenuItem);
    }

    private boolean handleMenuItem(@NonNull MenuItem item) {
        int id = item.getItemId();
        drawerLayout.closeDrawer(GravityCompat.END);

        if (id == R.id.menu_language_ar) {
            LocaleHelper.setLocale(this, "ar");
            recreate();
        } else if (id == R.id.menu_language_en) {
            LocaleHelper.setLocale(this, "en");
            recreate();
        } else if (id == R.id.menu_theme_dark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else if (id == R.id.menu_theme_light) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else if (id == R.id.menu_chat) {
            Intent intent = new Intent(this, FingerprintActivity.class);
            startActivity(intent); // فيه تحقق بالبصمة قبل فتح الشات
        }
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (rotationSensor != null)
            sensorManager.registerListener(this, rotationSensor, SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float degree = Math.round(event.values[0]);
        compassImage.setRotation(-degree);
        currentDegree = degree;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {}
}
