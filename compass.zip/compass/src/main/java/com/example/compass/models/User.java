package com.example.compass.models;

public class User {
    private String userId;
    private String name;
    private String email;
    private String profileImageUrl;
    private boolean online;

    public User() {
        // Required empty constructor for Firebase
    }

    public User(String userId, String name, String email, String profileImageUrl, boolean online) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.profileImageUrl = profileImageUrl;
        this.online = online;
    }

    public User(String uid, String name, String email, String online, String s, String s1) {
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }

    public void setProfileImageUrl(String profileImageUrl) {
        this.profileImageUrl = profileImageUrl;
    }

    public boolean isOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }



}
