package com.example.compass;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.compass.models.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {

    private EditText inputName, inputEmail, inputPassword;
    private ProgressBar progressBar;
    private FirebaseAuth auth;
    private FirebaseDatabase database;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // ربط عناصر الواجهة
        inputName     = findViewById(R.id.inputName);
        inputEmail    = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        progressBar   = findViewById(R.id.progressBar);

        // تهيئة Firebase
        auth     = FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();

        // زر التسجيل
        findViewById(R.id.btnRegister).setOnClickListener(view -> {
            String name     = inputName.getText().toString().trim();
            String email    = inputEmail.getText().toString().trim();
            String password = inputPassword.getText().toString().trim();

            // التحقق من الإدخالات
            if (TextUtils.isEmpty(name)) {
                inputName.setError("الاسم مطلوب");
                return;
            }
            if (TextUtils.isEmpty(email)) {
                inputEmail.setError("البريد الإلكتروني مطلوب");
                return;
            }
            if (TextUtils.isEmpty(password) || password.length() < 6) {
                inputPassword.setError("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
                return;
            }

            // إظهار شريط التقدم
            progressBar.setVisibility(View.VISIBLE);

            // إنشاء المستخدم في Firebase Auth
            auth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(task -> {
                        // إخفاء شريط التقدم
                        progressBar.setVisibility(View.GONE);
                        if (task.isSuccessful()) {
                            // جلب UID
                            String uid = task.getResult().getUser().getUid();
                            // إنشاء نموذج المستخدم
                            User user = new User(uid, name, email, "", true);
                            // حفظ بيانات المستخدم في Realtime Database
                            database.getReference("users")
                                    .child(uid)
                                    .setValue(user)
                                    .addOnCompleteListener(task1 -> {
                                        if (task1.isSuccessful()) {
                                            Toast.makeText(this, "تم التسجيل بنجاح", Toast.LENGTH_SHORT).show();
                                            startActivity(new Intent(this, MainActivity.class));
                                            finish();
                                        } else {
                                            Toast.makeText(this, "فشل حفظ بيانات المستخدم", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else {
                            Toast.makeText(this,
                                    "فشل التسجيل: " + task.getException().getMessage(),
                                    Toast.LENGTH_LONG).show();
                        }
                    });
        });

        // الانتقال لشاشة تسجيل الدخول
        findViewById(R.id.textLogin).setOnClickListener(view -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
