package com.example.compass.utils;

import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.compass.models.message;
import com.example.compass.models.User;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirebaseUtils {

    public static FirebaseUser getCurrentUser() {
        return FirebaseAuth.getInstance().getCurrentUser();
    }

    public static void updateUserStatus(String status) {
        FirebaseUser user = getCurrentUser();
        if (user != null) {
            FirebaseDatabase.getInstance().getReference("users")
                    .child(user.getUid())
                    .child("status")
                    .setValue(status);
        }
    }

    public static void getUserInfo(String userId, OnSuccessListener<User> listener) {
        FirebaseDatabase.getInstance().getReference("users")
                .child(userId)
                .get().addOnSuccessListener(dataSnapshot -> {
                    if (dataSnapshot.exists()) {
                        User user = dataSnapshot.getValue(User.class);
                        listener.onSuccess(user);
                    }
                });
    }

    public static void sendMessage(message message) {
        String senderRoom = message.getSenderId() + message.getReceiverId();
        String receiverRoom = message.getReceiverId() + message.getSenderId();

        FirebaseDatabase.getInstance().getReference("chats")
                .child(senderRoom)
                .child(message.getMessageId())
                .setValue(message);

        FirebaseDatabase.getInstance().getReference("chats")
                .child(receiverRoom)
                .child(message.getMessageId())
                .setValue(message);

        updateLastMessage(senderRoom, message);
        updateLastMessage(receiverRoom, message);
    }

    private static void updateLastMessage(String roomId, message message) {
        FirebaseDatabase.getInstance().getReference("lastMessages")
                .child(roomId)
                .setValue(message);
    }

    public static void listenForAppUpdate(Runnable onUpdateAvailable) {
        FirebaseDatabase.getInstance().getReference("updates")
                .child("latest")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Boolean updateAvailable = snapshot.getValue(Boolean.class);
                        if (updateAvailable != null && updateAvailable) {
                            onUpdateAvailable.run();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("FirebaseUtils", "Update check failed: " + error.getMessage());
                    }
                });
    }

    public static Uri getUserPhotoUrl() {
        FirebaseUser user = getCurrentUser();
        return user != null ? user.getPhotoUrl() : null;
    }
}
