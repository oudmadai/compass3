package com.example.compass;

import android.net.Uri;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class FirebaseStorageHelper {

    private static final String STORAGE_PATH = "chat_images/";

    public static void uploadImage(Uri imageUri, String imageName, final ImageUploadCallback callback) {
        StorageReference storageRef = FirebaseStorage.getInstance().getReference().child(STORAGE_PATH + imageName);
        UploadTask uploadTask = storageRef.putFile(imageUri);

        uploadTask.addOnSuccessListener(taskSnapshot -> {
            storageRef.getDownloadUrl().addOnSuccessListener(uri -> {
                callback.onSuccess(uri.toString());
            }).addOnFailureListener(callback::onFailure);
        }).addOnFailureListener(callback::onFailure);
    }

    public interface ImageUploadCallback {
        void onSuccess(String imageUrl);
        void onFailure(Exception exception);
    }
}
