package com.example.compass.adapters;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.compass.R;
import com.example.compass.models.message;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class MessageAdapter extends RecyclerView.Adapter {

    private Context context;
    private ArrayList<message> messages;
    private final int ITEM_SEND = 1;
    private final int ITEM_RECEIVE = 2;
    private String senderId;

    public MessageAdapter(Context context, ArrayList<message> messages, String senderId) {
        this.context = context;
        this.messages = messages;
        this.senderId = senderId;
    }

    @Override
    public int getItemViewType(int position) {
        if (messages.get(position).getSenderId().equals(senderId)) {
            return ITEM_SEND;
        } else {
            return ITEM_RECEIVE;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == ITEM_SEND) {
            View view = LayoutInflater.from(context).inflate(R.layout.item_sent, parent, false);
            return new SentViewHolder(view);
        } else {
            View view = LayoutInflater.from(context).inflate(R.layout.item_received, parent, false);
            return new ReceivedViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        message message = messages.get(position);

        if (holder.getClass() == SentViewHolder.class) {
            SentViewHolder viewHolder = (SentViewHolder) holder;
            bindMessage(viewHolder.textMessage, viewHolder.imageMessage, message);
        } else {
            ReceivedViewHolder viewHolder = (ReceivedViewHolder) holder;
            bindMessage(viewHolder.textMessage, viewHolder.imageMessage, message);
        }

        holder.itemView.setOnLongClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("خيارات الرسالة")
                    .setItems(new CharSequence[]{"نسخ", "حذف"}, (dialog, which) -> {
                        if (which == 0) {
                            if (message.getText() != null) {
                                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                                ClipData clip = ClipData.newPlainText("message", message.getText());
                                clipboard.setPrimaryClip(clip);
                                Toast.makeText(context, "تم النسخ", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            deleteMessage(message);
                        }
                    }).show();
            return true;
        });
    }

    private void bindMessage(TextView textView, ImageView imageView, message message) {
        if (message.getImageUrl() != null) {
            textView.setVisibility(View.GONE);
            imageView.setVisibility(View.VISIBLE);
            Glide.with(context).load(message.getImageUrl()).into(imageView);
        } else {
            imageView.setVisibility(View.GONE);
            textView.setVisibility(View.VISIBLE);
            textView.setText(message.getText());
        }
    }

    private void deleteMessage(message message) {
        String senderRoom = message.getSenderId();
        String receiverRoom = message.getReceiverId();
        if (message.getText() != null && message.getText().contains("حزف الدردشة")) {
            FirebaseDatabase.getInstance().getReference("chats")
                    .child(senderRoom)
                    .child(receiverRoom)
                    .removeValue();
            FirebaseDatabase.getInstance().getReference("chats")
                    .child(receiverRoom)
                    .child(senderRoom)
                    .removeValue();
        } else {
            FirebaseDatabase.getInstance().getReference("chats")
                    .child(senderRoom)
                    .child(receiverRoom)
                    .child(message.getMessageId())
                    .removeValue();
        }
    }

    @Override
    public int getItemCount() {
        return messages.size();
    }

    public static class SentViewHolder extends RecyclerView.ViewHolder {
        TextView textMessage;
        ImageView imageMessage;

        public SentViewHolder(@NonNull View itemView) {
            super(itemView);
            textMessage = itemView.findViewById(R.id.sentMessageText);
            imageMessage = itemView.findViewById(R.id.sentImageView);
        }
    }

    public static class ReceivedViewHolder extends RecyclerView.ViewHolder {
        TextView textMessage;
        ImageView imageMessage;

        public ReceivedViewHolder(@NonNull View itemView) {
            super(itemView);
            textMessage = itemView.findViewById(R.id.receivedMessageText);
            imageMessage = itemView.findViewById(R.id.receivedImageView);
        }
    }
}
