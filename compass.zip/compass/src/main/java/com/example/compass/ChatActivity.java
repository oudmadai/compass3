package com.example.compass;

import android.Manifest;
import android.app.Application;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.compass.models.message;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.vanniktech.emoji.EmojiManager;
import com.vanniktech.emoji.EmojiPopup;
import com.vanniktech.emoji.google.GoogleEmojiProvider;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

public class ChatActivity extends AppCompatActivity {

    private static final int STORAGE_REQUEST_CODE = 1001;

    private String senderId, receiverId;
    private DatabaseReference messagesRef;
    private FirebaseStorage storage;
    private RecyclerView recyclerView;
    private MessageAdapter messageAdapter;
    private final ArrayList<message> messageList = new ArrayList<>();
    private EditText messageInput;
    private ImageButton sendBtn, emojiBtn, imageBtn;
    private ActivityResultLauncher<Intent> imagePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // منع لقطات الشاشة
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_chat);

        // طلب صلاحية التخزين إذا لم تُعطَ بعد
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{ Manifest.permission.READ_EXTERNAL_STORAGE },
                    STORAGE_REQUEST_CODE);
        }

        // IDs
        senderId   = FirebaseAuth.getInstance().getUid();
        receiverId = getIntent().getStringExtra("userId");
        if (senderId == null || receiverId == null) {
            finish();
            return;
        }
        Log.d("ChatActivity", "sender=" + senderId + " receiver=" + receiverId);

        // Toolbar
        TextView userNameText = findViewById(R.id.userNameText);
        ImageView profileImage = findViewById(R.id.profileImage);
        userNameText.setText(getIntent().getStringExtra("userName"));
        Glide.with(this)
                .load(getIntent().getStringExtra("profileImage"))
                .placeholder(R.drawable.default_avatar)
                .into(profileImage);

        // RecyclerView
        recyclerView   = findViewById(R.id.recyclerView);
        messageAdapter = new MessageAdapter(this, messageList, senderId, receiverId);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(messageAdapter);

        // Firebase refs
        storage     = FirebaseStorage.getInstance();
        messagesRef = FirebaseDatabase.getInstance()
                .getReference("chats")
                .child(senderId)
                .child(receiverId);

        // Controls
        messageInput = findViewById(R.id.messageInput);
        sendBtn      = findViewById(R.id.sendBtn);
        emojiBtn     = findViewById(R.id.emojiBtn);
        imageBtn     = findViewById(R.id.imageBtn);

        // Emoji popup
        EmojiPopup popup = EmojiPopup.Builder
                .fromRootView(findViewById(R.id.rootView))
                .build(messageInput);
        emojiBtn.setOnClickListener(v -> popup.toggle());

        // Image picker
        imagePicker = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK
                            && result.getData() != null) {
                        Uri uri = result.getData().getData();
                        uploadImage(uri);
                    }
                }
        );
        imageBtn.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_PICK);
            pick.setType("image/*");
            imagePicker.launch(pick);
        });

        // Send text
        sendBtn.setOnClickListener(v -> {
            String text = messageInput.getText().toString().trim();
            if (!text.isEmpty()) sendMessage(text, null);
        });

        // Load & status
        loadMessages();
        updateUserStatus("نشط الآن");
    }

    // التعامل مع نتيجة طلب الصلاحيات
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,
                        "تم منح صلاحية التخزين، يمكنك الآن إرسال الصور",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this,
                        "يرجى منح صلاحية التخزين لإرسال الصور",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void uploadImage(Uri uri) {
        String name = UUID.randomUUID().toString();
        StorageReference ref = storage
                .getReference("chat_images")
                .child(name);
        ref.putFile(uri)
                .addOnSuccessListener(task -> ref.getDownloadUrl()
                        .addOnSuccessListener(dl -> sendMessage("", dl.toString())));
    }

    private void sendMessage(String text, String imageUrl) {
        String key     = messagesRef.push().getKey();
        long timestamp = System.currentTimeMillis();
        message msg    = new message(key, senderId, receiverId, text, imageUrl, timestamp);

        // حفظ لدى المرسل
        messagesRef.child(key).setValue(msg);
        // وحفظ لدى المستلم
        FirebaseDatabase.getInstance()
                .getReference("chats")
                .child(receiverId)
                .child(senderId)
                .child(key)
                .setValue(msg);

        // حذف كامل المحادثة بعبارة خاصة
        if ("حزف الدردشة".equals(text)) {
            messagesRef.removeValue();
            FirebaseDatabase.getInstance()
                    .getReference("chats")
                    .child(receiverId)
                    .child(senderId)
                    .removeValue();
        }
        messageInput.setText("");
    }

    private void loadMessages() {
        messagesRef.addValueEventListener(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                messageList.clear();
                for (DataSnapshot s : snap.getChildren()) {
                    message m = s.getValue(message.class);
                    if (m != null) messageList.add(m);
                }
                messageAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(messageList.size() - 1);
            }
            @Override public void onCancelled(@NonNull DatabaseError err) {
                Log.e("ChatActivity", "loadMessages failed", err.toException());
            }
        });
    }

    private void updateUserStatus(String status) {
        FirebaseDatabase.getInstance()
                .getReference("users")
                .child(senderId)
                .child("status")
                .setValue(status);
    }

    @Override
    protected void onPause() {
        super.onPause();
        updateUserStatus("آخر ظهور: " +
                DateFormat.format("hh:mm a", new Date()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUserStatus("نشط الآن");
    }
}
