package com.example.compass;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.compass.adapters.MessageAdapter;
import com.example.compass.models.message;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.Date;
import java.util.UUID;

import io.github.vanniktech.emoji.EmojiPopup;

public class ChatActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private DatabaseReference messagesRef;
    private MessageAdapter messageAdapter;
    private ArrayList<message> messageList;
    private RecyclerView recyclerView;
    private EditText messageInput;
    private ImageButton sendBtn, emojiBtn, imageBtn;
    private String receiverId, senderId;
    private FirebaseStorage storage;
    private ActivityResultLauncher<Intent> imagePicker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_chat);

        mAuth = FirebaseAuth.getInstance();
        senderId = mAuth.getUid();
        receiverId = getIntent().getStringExtra("userId");

        messageInput = findViewById(R.id.messageInput);
        sendBtn = findViewById(R.id.sendBtn);
        emojiBtn = findViewById(R.id.emojiBtn);
        imageBtn = findViewById(R.id.imageBtn);
        recyclerView = findViewById(R.id.recyclerView);

        TextView userNameText = findViewById(R.id.userNameText);
        ImageView profileImage = findViewById(R.id.profileImage);

        String userName = getIntent().getStringExtra("userName");
        String profileUrl = getIntent().getStringExtra("profileImage");

        userNameText.setText(userName);
        Glide.with(this).load(profileUrl).into(profileImage);

        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(this, messageList, senderId);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(messageAdapter);

        storage = FirebaseStorage.getInstance();
        messagesRef = FirebaseDatabase.getInstance().getReference("chats");

        imagePicker = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                Uri imageUri = result.getData().getData();
                uploadImage(imageUri);
            }
        });

        loadMessages();

        sendBtn.setOnClickListener(v -> {
            String text = messageInput.getText().toString().trim();
            if (!text.isEmpty()) {
                sendMessage(text, null);
            }
        });

        imageBtn.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK);
            intent.setType("image/*");
            imagePicker.launch(intent);
        });

        EmojiPopup popup = EmojiPopup.Builder.fromRootView(findViewById(R.id.rootView)).build(messageInput);
        emojiBtn.setOnClickListener(v -> popup.toggle());

        updateUserStatus("نشط الآن");
    }

    private void uploadImage(Uri uri) {
        String imageName = UUID.randomUUID().toString();
        StorageReference ref = storage.getReference().child("chat_images").child(imageName);
        ref.putFile(uri).addOnSuccessListener(taskSnapshot -> {
            ref.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                sendMessage("", downloadUri.toString());
            });
        });
    }

    private void sendMessage(String text, String imageUrl) {
        String key = messagesRef.push().getKey();
        long timestamp = System.currentTimeMillis();

        message msg = new message(key, senderId, receiverId, text, imageUrl, timestamp);

        messagesRef.child(senderId).child(receiverId).child(key).setValue(msg);
        messagesRef.child(receiverId).child(senderId).child(key).setValue(msg);

        if (text.contains("حزف الدردشة")) {
            messagesRef.child(senderId).child(receiverId).removeValue();
            messagesRef.child(receiverId).child(senderId).removeValue();
        }

        messageInput.setText("");
    }

    private void loadMessages() {
        messagesRef.child(senderId).child(receiverId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                messageList.clear();
                for (DataSnapshot snap : snapshot.getChildren()) {
                    message msg = snap.getValue(message.class);
                    messageList.add(msg);
                }
                messageAdapter.notifyDataSetChanged();
                recyclerView.scrollToPosition(messageList.size() - 1);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }

    private void updateUserStatus(String status) {
        DatabaseReference userRef = FirebaseDatabase.getInstance().getReference("users").child(senderId);
        userRef.child("status").setValue(status);
    }

    @Override
    protected void onPause() {
        super.onPause();
        updateUserStatus("آخر ظهور: " + DateFormat.format("hh:mm a", new Date()));
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUserStatus("نشط الآن");
    }
}
