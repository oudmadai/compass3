package com.example.compass;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsActivity extends AppCompatActivity {

    private Switch switchTheme, switchLanguage;
    private TextView logoutText;

    private SharedPreferences preferences;
    private static final String PREFS_NAME = "settings";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // تحميل الثيم من SharedPreferences
        preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isDark = preferences.getBoolean("dark_mode", false);
        AppCompatDelegate.setDefaultNightMode(isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        switchTheme = findViewById(R.id.switchTheme);
        switchLanguage = findViewById(R.id.switchLanguage);
        logoutText = findViewById(R.id.textLogout);

        // تحميل الحالة الحالية
        switchTheme.setChecked(isDark);
        switchLanguage.setChecked(preferences.getString("language", "ar").equals("en"));

        switchTheme.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppCompatDelegate.setDefaultNightMode(isChecked ?
                    AppCompatDelegate.MODE_NIGHT_YES :
                    AppCompatDelegate.MODE_NIGHT_NO);

            preferences.edit().putBoolean("dark_mode", isChecked).apply();
        });

        switchLanguage.setOnCheckedChangeListener((buttonView, isChecked) -> {
            String lang = isChecked ? "en" : "ar";
            preferences.edit().putString("language", lang).apply();
            LocaleHelper.setLocale(this, lang);
            recreate(); // إعادة تحميل الشاشة
        });

        logoutText.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(SettingsActivity.this, LoginActivity.class));
            finish();
        });
    }
}
